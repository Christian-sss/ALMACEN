-- Historial de demostración: transferencias y retiros en fechas anteriores (últimos 6 meses),
-- con sus movimientos, para el historial, la auditoría y las estadísticas del administrador.
--
-- Requisitos: docs/referencia_transaccion.sql y docs/tipos_transaccion.sql ya ejecutados, y al
-- menos 2 clientes registrados desde la app (con billetera ACTIVA).
--
-- Usa las billeteras que ya existen (hasta 8). Cada una recibe una carga inicial de S/ 3,000
-- (hace 185 días) para poder operar, y los saldos finales quedan cuadrados con sus movimientos.
-- Se ejecuta UNA sola vez: si ya hay datos de demo (referencia 'DEMO-SEED'), no hace nada.
-- Todo ocurre en un solo bloque: si algo falla, no queda nada a medias.

DO $demo$
DECLARE
    v_tipo_carga   BIGINT;
    v_tipo_transf  BIGINT;
    v_tipo_retiro  BIGINT;
    v_billeteras   BIGINT[];
    v_n            INT;
    ev             RECORD;
    v_tx           BIGINT;
    v_saldo_a      NUMERIC;
    v_saldo_b      NUMERIC;
    n_ok           INT := 0;
    n_omitidas     INT := 0;
BEGIN
    IF EXISTS (SELECT 1 FROM billetera.transaccion WHERE referencia = 'DEMO-SEED') THEN
        RAISE NOTICE 'Los datos de demo ya existen: no se hace nada.';
        RETURN;
    END IF;

    SELECT id INTO v_tipo_carga  FROM billetera.tipo_transaccion WHERE codigo = 'CARGA_INICIAL';
    SELECT id INTO v_tipo_transf FROM billetera.tipo_transaccion WHERE codigo = 'TRANSFERENCIA';
    SELECT id INTO v_tipo_retiro FROM billetera.tipo_transaccion WHERE codigo = 'RETIRO';

    IF v_tipo_carga IS NULL OR v_tipo_transf IS NULL OR v_tipo_retiro IS NULL THEN
        RAISE EXCEPTION 'Faltan tipos de transacción. Ejecuta primero docs/tipos_transaccion.sql';
    END IF;

    SELECT array_agg(id ORDER BY id) INTO v_billeteras
    FROM (SELECT id FROM billetera.billetera WHERE estado = 'ACTIVA' ORDER BY id LIMIT 8) s;
    v_n := COALESCE(array_length(v_billeteras, 1), 0);

    IF v_n < 2 THEN
        RAISE EXCEPTION 'Se necesitan al menos 2 billeteras activas. Registra clientes desde la app y vuelve a ejecutar.';
    END IF;

    -- Saldo corriente de cada billetera mientras se reproducen los eventos en orden cronológico.
    CREATE TEMP TABLE _w (id BIGINT PRIMARY KEY, saldo NUMERIC(12,2) NOT NULL) ON COMMIT DROP;
    INSERT INTO _w SELECT id, saldo FROM billetera.billetera WHERE id = ANY (v_billeteras);

    CREATE TEMP TABLE _ev (
        ts    TIMESTAMPTZ   NOT NULL,
        kind  TEXT          NOT NULL,   -- CARGA | TRANSFER | RETIRO
        a     BIGINT        NOT NULL,   -- billetera de origen
        b     BIGINT,                   -- billetera de destino (solo TRANSFER)
        monto NUMERIC(12,2) NOT NULL,
        ref   TEXT
    ) ON COMMIT DROP;

    INSERT INTO _ev (ts, kind, a, monto, ref)
    SELECT now() - interval '185 days' + (row_number() OVER (ORDER BY id)) * interval '1 minute',
           'CARGA', id, 3000.00, 'DEMO-SEED'
    FROM _w;

    -- 60 operaciones: 40 % en los últimos 7 días y el resto en los 6 meses anteriores.
    -- El 80 % son transferencias y el 20 % retiros.
    INSERT INTO _ev (ts, kind, a, b, monto, ref)
    SELECT g.ts,
           CASE WHEN g.r < 0.20 THEN 'RETIRO' ELSE 'TRANSFER' END,
           v_billeteras[g.pos_a],
           CASE WHEN g.r >= 0.20 THEN v_billeteras[1 + ((g.pos_a + g.salto) % v_n)] END,
           g.monto,
           CASE WHEN g.r < 0.20
                THEN (ARRAY['BCP', 'BBVA', 'Interbank', 'Scotiabank'])[1 + floor(random() * 4)::int]
                     || ' ****' || lpad(floor(random() * 10000)::int::text, 4, '0') END
    FROM (
        SELECT now() - make_interval(secs => CASE WHEN random() < 0.4
                                                   THEN random() * 7 * 86400
                                                   ELSE (7 + random() * 173) * 86400 END) AS ts,
               random() AS r,
               1 + floor(random() * v_n)::int AS pos_a,
               floor(random() * (v_n - 1))::int AS salto,       -- 0..n-2: el destino nunca es el origen
               round((10 + random() * random() * 390)::numeric, 2) AS monto
        FROM generate_series(1, 60)
    ) g;

    FOR ev IN SELECT * FROM _ev ORDER BY ts, kind LOOP
        SELECT saldo INTO v_saldo_a FROM _w WHERE id = ev.a;

        IF ev.kind = 'CARGA' THEN
            INSERT INTO billetera.transaccion (tipo_id, monto, comision, estado, referencia, fecha)
            VALUES (v_tipo_carga, ev.monto, 0, 'EXITOSA', ev.ref, ev.ts) RETURNING id INTO v_tx;
            v_saldo_a := v_saldo_a + ev.monto;
            INSERT INTO billetera.movimiento (transaccion_id, billetera_id, signo, monto, saldo_posterior)
            VALUES (v_tx, ev.a, '+', ev.monto, v_saldo_a);

        ELSIF ev.kind = 'TRANSFER' THEN
            IF v_saldo_a < ev.monto THEN
                n_omitidas := n_omitidas + 1;
                CONTINUE;
            END IF;
            SELECT saldo INTO v_saldo_b FROM _w WHERE id = ev.b;
            INSERT INTO billetera.transaccion (tipo_id, monto, comision, estado, referencia, fecha)
            VALUES (v_tipo_transf, ev.monto, 0, 'EXITOSA', NULL, ev.ts) RETURNING id INTO v_tx;
            v_saldo_a := v_saldo_a - ev.monto;
            v_saldo_b := v_saldo_b + ev.monto;
            INSERT INTO billetera.movimiento (transaccion_id, billetera_id, signo, monto, saldo_posterior)
            VALUES (v_tx, ev.a, '-', ev.monto, v_saldo_a),
                   (v_tx, ev.b, '+', ev.monto, v_saldo_b);
            UPDATE _w SET saldo = v_saldo_b WHERE id = ev.b;

        ELSE -- RETIRO
            IF v_saldo_a < ev.monto THEN
                n_omitidas := n_omitidas + 1;
                CONTINUE;
            END IF;
            INSERT INTO billetera.transaccion (tipo_id, monto, comision, estado, referencia, fecha)
            VALUES (v_tipo_retiro, ev.monto, 0, 'EXITOSA', ev.ref, ev.ts) RETURNING id INTO v_tx;
            v_saldo_a := v_saldo_a - ev.monto;
            INSERT INTO billetera.movimiento (transaccion_id, billetera_id, signo, monto, saldo_posterior)
            VALUES (v_tx, ev.a, '-', ev.monto, v_saldo_a);
        END IF;

        UPDATE _w SET saldo = v_saldo_a WHERE id = ev.a;
        n_ok := n_ok + 1;
    END LOOP;

    UPDATE billetera.billetera b SET saldo = _w.saldo FROM _w WHERE b.id = _w.id;

    RAISE NOTICE 'Listo: % operaciones creadas (% omitidas por saldo insuficiente).', n_ok, n_omitidas;
END
$demo$;
