-- Una fila por cuenta con sesión abierta. La clave primaria impide dos sesiones simultáneas.
-- Ejecutar una vez en la base de datos antes de usar la app.
CREATE TABLE IF NOT EXISTS seguridad.sesion_activa (
    usuario_id    BIGINT PRIMARY KEY REFERENCES seguridad.usuario (id),
    token         VARCHAR(64) NOT NULL,
    fecha_inicio  TIMESTAMP   NOT NULL DEFAULT now(),
    ultimo_latido TIMESTAMP   NOT NULL DEFAULT now()
);
