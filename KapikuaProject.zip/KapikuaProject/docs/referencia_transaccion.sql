-- Banco/cuenta de un retiro ("BCP ****1234") o contexto del movimiento ("Préstamo #5 · Cuota 2").
-- Ejecutar una vez en la base de datos; es seguro repetirlo.
ALTER TABLE billetera.transaccion
    ADD COLUMN IF NOT EXISTS referencia VARCHAR(100);
