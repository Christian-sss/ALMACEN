-- Tipos de transacción que usa la app (ver sección 8 del plan). Inserta solo los que falten;
-- es seguro repetirlo. Antes, revisa lo que ya existe:
--     SELECT * FROM billetera.tipo_transaccion;
INSERT INTO billetera.tipo_transaccion (codigo, naturaleza)
SELECT v.codigo, v.naturaleza
FROM (VALUES
          ('CARGA_INICIAL',      'CREDITO'),
          ('TRANSFERENCIA',      'DEBITO'),
          ('RETIRO',             'DEBITO'),
          ('DESEMBOLSO_CREDITO', 'CREDITO'),
          ('PAGO_CREDITO',       'DEBITO')
     ) AS v (codigo, naturaleza)
WHERE NOT EXISTS (
    SELECT 1 FROM billetera.tipo_transaccion t WHERE t.codigo = v.codigo
);
