package com.projects.domain.model.billetera;

import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.result.BilleteraError;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BilleteraTest {

    private static Billetera conSaldo(String saldo, EstadoBilletera estado) {
        return Billetera.reconstruir(1L, 10L, new BigDecimal(saldo), estado, OffsetDateTime.now());
    }

    @Test
    void seAbreActivaYConSaldoCero() {
        var billetera = Billetera.abrirPara(10L, OffsetDateTime.now()).getValue().orElseThrow();

        assertMonto("0", billetera.getSaldo());
        assertEquals(EstadoBilletera.ACTIVA, billetera.getEstadoBilletera());
        assertNull(billetera.getId());
    }

    @Test
    void noSeAbreSinClienteNiSinFecha() {
        assertEquals(BilleteraError.CLIENTE_REQUERIDO.name(), codigo(Billetera.abrirPara(null, OffsetDateTime.now())));
        assertEquals(BilleteraError.FECHA_INVALIDA.name(), codigo(Billetera.abrirPara(10L, null)));
    }

    @Test
    void elDepositoSumaAlSaldo() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertTrue(billetera.deposit(new BigDecimal("25.50")).isSuccess());
        assertMonto("125.50", billetera.getSaldo());
    }

    @Test
    void elDepositoRechazaMontosNulosCeroONegativos() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.deposit(null)));
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.deposit(BigDecimal.ZERO)));
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.deposit(new BigDecimal("-0.01"))));
        assertMonto("100.00", billetera.getSaldo());
    }

    @Test
    void elRetiroRestaDelSaldo() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertTrue(billetera.withDraw(new BigDecimal("30.25")).isSuccess());
        assertMonto("69.75", billetera.getSaldo());
    }

    @Test
    void sePuedeRetirarExactamenteTodoElSaldo() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertTrue(billetera.withDraw(new BigDecimal("100.00")).isSuccess());
        assertMonto("0", billetera.getSaldo());
    }

    @Test
    void elRetiroNoPuedeDejarElSaldoEnNegativo() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertEquals(BilleteraError.SALDO_INSUFICIENTE.name(), codigo(billetera.withDraw(new BigDecimal("100.01"))));
        assertMonto("100.00", billetera.getSaldo());
    }

    // Un retiro negativo sería un depósito encubierto.
    @Test
    void elRetiroRechazaMontosNulosCeroONegativos() {
        var billetera = conSaldo("100.00", EstadoBilletera.ACTIVA);

        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.withDraw(null)));
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.withDraw(BigDecimal.ZERO)));
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(), codigo(billetera.withDraw(new BigDecimal("-50"))));
        assertMonto("100.00", billetera.getSaldo());
    }

    @Test
    void unaBilleteraBloqueadaNoOpera() {
        var billetera = conSaldo("100.00", EstadoBilletera.BLOQUEADA);

        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(), codigo(billetera.deposit(new BigDecimal("10"))));
        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(), codigo(billetera.withDraw(new BigDecimal("10"))));
        assertMonto("100.00", billetera.getSaldo());
    }
}
