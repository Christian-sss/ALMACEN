package com.projects.domain.model.seguridad;

import com.projects.domain.result.UsuarioError;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UsuarioTest {

    private static final OffsetDateTime AHORA = OffsetDateTime.now();

    @Test
    void seCreaActivoYConElEmailEnMinusculas() {
        var usuario = Usuario.crear("Ana.Torres@GMAIL.com", "hash", 1L, AHORA).getValue().orElseThrow();

        assertEquals("ana.torres@gmail.com", usuario.getEmail());
        assertTrue(usuario.getActivo());
        assertEquals(1L, usuario.getRolId());
    }

    @Test
    void aceptaSoloLosDominiosPermitidos() {
        for (var email : new String[]{"a@upt.pe", "a@virtual.upt.pe", "a@gmail.com", "a@outlook.com"}) {
            assertTrue(Usuario.validarDatos(email, "hash").isSuccess(), email);
        }
        for (var email : new String[]{"a@yahoo.com", "a@hotmail.com", "a@gmail.com.pe", "a@fakegmail.com"}) {
            assertEquals(UsuarioError.EMAIL_DOMINIO_NO_PERMITIDO.name(), codigo(Usuario.validarDatos(email, "hash")), email);
        }
    }

    @Test
    void rechazaEmailsVaciosOMalFormados() {
        assertEquals(UsuarioError.EMAIL_INVALIDO.name(), codigo(Usuario.validarDatos(null, "hash")));
        assertEquals(UsuarioError.EMAIL_INVALIDO.name(), codigo(Usuario.validarDatos("   ", "hash")));

        for (var email : new String[]{"ana", "ana@", "@gmail.com", "ana@gmail", "ana torres@gmail.com", "ana@@gmail.com",
                "ana@gmail.com' OR '1'='1"}) {
            assertEquals(UsuarioError.EMAI_FORMAT_IMVALIDO.name(), codigo(Usuario.validarDatos(email, "hash")), email);
        }
    }

    @Test
    void laContrasenaEsObligatoria() {
        assertEquals(UsuarioError.PASSWORD_INVALIDO.name(), codigo(Usuario.validarDatos("a@gmail.com", null)));
        assertEquals(UsuarioError.PASSWORD_INVALIDO.name(), codigo(Usuario.validarDatos("a@gmail.com", "      ")));
    }

    @Test
    void noSeCreaSinRolNiSinFecha() {
        assertEquals(UsuarioError.ROL_REQUERIDO.name(), codigo(Usuario.crear("a@gmail.com", "hash", null, AHORA)));
        assertEquals(UsuarioError.FECHA_INVALIDA.name(), codigo(Usuario.crear("a@gmail.com", "hash", 1L, null)));
    }
}
