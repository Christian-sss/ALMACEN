package com.projects.domain.model.billetera;

import com.projects.domain.result.ClienteError;
import com.projects.domain.result.Result;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClienteTest {

    private static final OffsetDateTime HOY = OffsetDateTime.of(2026, 10, 1, 12, 0, 0, 0, ZoneOffset.UTC);
    private static final LocalDate NACIMIENTO = LocalDate.of(2000, 3, 15);

    private static Result<Void> validar(String nombres, String apellidos, String dni, String celular, LocalDate nacimiento) {
        return Cliente.validarDatos(nombres, apellidos, dni, celular, nacimiento, HOY);
    }

    @Test
    void aceptaDatosValidosYRecortaEspacios() {
        var cliente = Cliente.crear(7L, "  Ana María ", " Torres Flores ", " 45871236 ", " 951753468 ", NACIMIENTO, HOY)
                .getValue().orElseThrow();

        assertEquals("Ana María", cliente.getNombres());
        assertEquals("Torres Flores", cliente.getApellidos());
        assertEquals("45871236", cliente.getDni());
        assertEquals("951753468", cliente.getNumeroCelular());
        assertEquals(7L, cliente.getUsuarioId());
    }

    @Test
    void exigeNombresYApellidos() {
        assertEquals(ClienteError.NOMBRE_INVALIDO.name(), codigo(validar(null, "Torres", "45871236", "951753468", NACIMIENTO)));
        assertEquals(ClienteError.NOMBRE_INVALIDO.name(), codigo(validar("   ", "Torres", "45871236", "951753468", NACIMIENTO)));
        assertEquals(ClienteError.APELLIDO_INVALIDO.name(), codigo(validar("Ana", "", "45871236", "951753468", NACIMIENTO)));
    }

    @Test
    void elDniDebeTenerOchoDigitos() {
        for (var dni : new String[]{null, "", "4587123", "458712366", "4587123A", "45 87123", "-4587123"}) {
            assertEquals(ClienteError.DNI_INVALIDO.name(),
                    codigo(validar("Ana", "Torres", dni, "951753468", NACIMIENTO)), "dni: " + dni);
        }
    }

    @Test
    void rechazaDniDeRelleno() {
        for (var dni : new String[]{"00000000", "11111111", "12345678", "87654321"}) {
            assertEquals(ClienteError.DNI_INVALIDO.name(),
                    codigo(validar("Ana", "Torres", dni, "951753468", NACIMIENTO)), "dni: " + dni);
        }
    }

    @Test
    void elCelularDebeTenerNueveDigitos() {
        for (var celular : new String[]{null, "", "95175346", "9517534688", "95175346A", "+51951753"}) {
            assertEquals(ClienteError.CELULAR_INVALIDO.name(),
                    codigo(validar("Ana", "Torres", "45871236", celular, NACIMIENTO)), "celular: " + celular);
        }
    }

    @Test
    void rechazaCelularesDeRelleno() {
        for (var celular : new String[]{"999999999", "123456789", "987654321"}) {
            assertEquals(ClienteError.CELULAR_INVALIDO.name(),
                    codigo(validar("Ana", "Torres", "45871236", celular, NACIMIENTO)), "celular: " + celular);
        }
    }

    @Test
    void laFechaDeNacimientoEsObligatoriaYNoPuedeSerFutura() {
        assertEquals(ClienteError.FECHA_NACIMIENTO_INVALIDA.name(),
                codigo(validar("Ana", "Torres", "45871236", "951753468", null)));
        assertEquals(ClienteError.FECHA_NACIMIENTO_INVALIDA.name(),
                codigo(validar("Ana", "Torres", "45871236", "951753468", LocalDate.of(2026, 10, 2))));
    }

    // Valor límite: 18 años se cumplen el mismo día y mes.
    @Test
    void laMayoriaDeEdadSeCumpleElDiaDelCumpleanos() {
        assertTrue(validar("Ana", "Torres", "45871236", "951753468", LocalDate.of(2008, 10, 1)).isSuccess());
        assertEquals(ClienteError.MENOR_DE_EDAD.name(),
                codigo(validar("Ana", "Torres", "45871236", "951753468", LocalDate.of(2008, 10, 2))));
    }

    @Test
    void noSeCreaSinUsuario() {
        assertEquals(ClienteError.USUARIO_REQUERIDO.name(),
                codigo(Cliente.crear(null, "Ana", "Torres", "45871236", "951753468", NACIMIENTO, HOY)));
    }

    @Disabled("HALLAZGO H5: validarDatos solo comprueba que el nombre no esté vacío; acepta dígitos y símbolos.")
    @Test
    void rechazaNombresConDigitosOSimbolos() {
        assertEquals(ClienteError.NOMBRE_INVALIDO.name(), codigo(validar("Ana123", "Torres", "45871236", "951753468", NACIMIENTO)));
        assertEquals(ClienteError.APELLIDO_INVALIDO.name(), codigo(validar("Ana", "<b>Torres</b>", "45871236", "951753468", NACIMIENTO)));
    }
}
