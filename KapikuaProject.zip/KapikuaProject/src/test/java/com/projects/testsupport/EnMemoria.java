package com.projects.testsupport;

import com.projects.application.dto.response.CuotaCronogramaResponse;
import com.projects.application.dto.response.PrestamoResumenResponse;
import com.projects.application.dto.response.SesionIniciadaResponse;
import com.projects.application.port.out.BilleteraRepository;
import com.projects.application.port.out.ClienteRepository;
import com.projects.application.port.out.CuotaRepository;
import com.projects.application.port.out.HistorialCrediticioQuery;
import com.projects.application.port.out.MovimientoRepository;
import com.projects.application.port.out.PagoRepository;
import com.projects.application.port.out.PasswordHasher;
import com.projects.application.port.out.PrestamoQuery;
import com.projects.application.port.out.PrestamoRepository;
import com.projects.application.port.out.ProductoRepository;
import com.projects.application.port.out.RolRepository;
import com.projects.application.port.out.SesionContexto;
import com.projects.application.port.out.SesionRepository;
import com.projects.application.port.out.SolicitudCreditoRepository;
import com.projects.application.port.out.TipoTransaccionRepository;
import com.projects.application.port.out.TransaccionRepository;
import com.projects.application.port.out.TransactionManager;
import com.projects.application.port.out.UsuarioRepository;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.model.EstadoCuota;
import com.projects.domain.model.TipoProductoCrediticio;
import com.projects.domain.model.billetera.Billetera;
import com.projects.domain.model.billetera.Cliente;
import com.projects.domain.model.billetera.Movimiento;
import com.projects.domain.model.billetera.Transaccion;
import com.projects.domain.model.credito.Cuota;
import com.projects.domain.model.credito.Pago;
import com.projects.domain.model.credito.PagoDetalle;
import com.projects.domain.model.credito.Prestamo;
import com.projects.domain.model.credito.ProductoCrediticio;
import com.projects.domain.model.credito.SolicitudCredito;
import com.projects.domain.model.seguridad.Rol;
import com.projects.domain.model.seguridad.Usuario;
import com.projects.domain.result.DomainError;
import com.projects.domain.result.Result;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Implementaciones en memoria de los puertos de salida. Permiten probar los casos de uso sin
 * PostgreSQL: cada servicio recibe estos dobles en su constructor igual que recibe los adaptadores
 * reales en CompositionRoot.
 */
public final class EnMemoria {

    private EnMemoria() {
    }

    public static String codigo(Result<?> resultado) {
        return resultado.getError().map(DomainError::code).orElse(null);
    }

    // BigDecimal.equals distingue 10.0 de 10.00; para dinero se compara el valor.
    public static void assertMonto(String esperado, BigDecimal actual) {
        assertEquals(0, new BigDecimal(esperado).compareTo(actual),
                "se esperaba " + esperado + " pero fue " + actual);
    }

    public static class Transacciones implements TransactionManager {

        public int confirmadas;
        public int revertidas;

        @Override
        public <T> Result<T> enTransaccion(Supplier<Result<T>> work) {
            Result<T> resultado = work.get();
            if (resultado.isFailure()) {
                revertidas++;
            } else {
                confirmadas++;
            }
            return resultado;
        }
    }

    public static class Billeteras implements BilleteraRepository {

        private final Map<Long, Billetera> porId = new LinkedHashMap<>();
        private long secuencia = 100;

        public Billeteras con(long id, long clienteId, String saldo, EstadoBilletera estado) {
            porId.put(id, Billetera.reconstruir(id, clienteId, new BigDecimal(saldo), estado, OffsetDateTime.now()));
            return this;
        }

        public BigDecimal saldoDe(long id) {
            return porId.get(id).getSaldo();
        }

        public int total() {
            return porId.size();
        }

        @Override
        public Optional<Billetera> save(Billetera billetera) {
            billetera.setId(++secuencia);
            porId.put(billetera.getId(), copia(billetera));
            return Optional.of(billetera);
        }

        @Override
        public Optional<Billetera> findByClienteId(Long clienteId) {
            return porId.values().stream()
                    .filter(billetera -> billetera.getClienteId().equals(clienteId))
                    .findFirst()
                    .map(Billeteras::copia);
        }

        // Devuelve una copia, como hace JDBC: lo que el servicio cambie en la entidad no llega
        // al "almacén" hasta que llama a actualizarSaldo.
        @Override
        public Optional<Billetera> findByIdParaActualizar(Long id) {
            return Optional.ofNullable(porId.get(id)).map(Billeteras::copia);
        }

        // billetera.billetera.saldo es NUMERIC(12,2): PostgreSQL redondea al guardar.
        @Override
        public void actualizarSaldo(Billetera billetera) {
            porId.get(billetera.getId()).setSaldo(billetera.getSaldo().setScale(2, RoundingMode.HALF_UP));
        }

        private static Billetera copia(Billetera billetera) {
            return Billetera.reconstruir(billetera.getId(), billetera.getClienteId(), billetera.getSaldo(),
                    billetera.getEstadoBilletera(), billetera.getFechaCreacion());
        }
    }

    public static class Clientes implements ClienteRepository {

        public final List<Cliente> guardados = new ArrayList<>();
        private long secuencia = 100;

        public Clientes con(long id, long usuarioId, String nombres, String apellidos, String dni, String celular) {
            guardados.add(Cliente.reconstruir(id, usuarioId, nombres, apellidos, dni, celular,
                    LocalDate.of(1995, 5, 20), OffsetDateTime.now()));
            return this;
        }

        @Override
        public Optional<Cliente> save(Cliente cliente) {
            cliente.setId(++secuencia);
            guardados.add(cliente);
            return Optional.of(cliente);
        }

        @Override
        public boolean existsByDni(String dni) {
            return guardados.stream().anyMatch(cliente -> cliente.getDni().equals(dni));
        }

        @Override
        public boolean existsByCelular(String celular) {
            return findByCelular(celular).isPresent();
        }

        @Override
        public Optional<Cliente> findByCelular(String celular) {
            return guardados.stream().filter(cliente -> cliente.getNumeroCelular().equals(celular)).findFirst();
        }

        @Override
        public Optional<Cliente> findByUsuarioId(Long usuarioId) {
            return guardados.stream().filter(cliente -> cliente.getUsuarioId().equals(usuarioId)).findFirst();
        }
    }

    public static class Usuarios implements UsuarioRepository {

        public final List<Usuario> guardados = new ArrayList<>();
        private long secuencia = 100;

        public Usuarios con(long id, long rolId, String email, String passwordHash, boolean activo) {
            guardados.add(Usuario.reconstruir(id, rolId, email, passwordHash, activo, OffsetDateTime.now()));
            return this;
        }

        @Override
        public Optional<Usuario> save(Usuario usuario) {
            usuario.setId(++secuencia);
            guardados.add(usuario);
            return Optional.of(usuario);
        }

        @Override
        public boolean existsByEmail(String email) {
            return findByEmail(email).isPresent();
        }

        @Override
        public Optional<Usuario> findByEmail(String email) {
            return guardados.stream().filter(usuario -> usuario.getEmail().equals(email)).findFirst();
        }
    }

    public static class Roles implements RolRepository {

        public static final long CLIENTE = 1;
        public static final long ADMIN = 2;

        private final List<Rol> roles = List.of(new Rol(CLIENTE, "CLIENTE"), new Rol(ADMIN, "ADMIN"));

        @Override
        public Optional<Rol> findByNombre(String nombreRol) {
            return roles.stream().filter(rol -> rol.getNombreRol().equals(nombreRol)).findFirst();
        }

        @Override
        public Optional<Rol> findById(Long id) {
            return roles.stream().filter(rol -> rol.getId().equals(id)).findFirst();
        }
    }

    // No es BCrypt: basta con que el hash sea distinto del texto plano y verificable.
    public static class Hasher implements PasswordHasher {

        @Override
        public String encriptar(String password) {
            return "hash(" + password + ")";
        }

        @Override
        public boolean validar(String passwordText, String passwordHash) {
            return encriptar(passwordText).equals(passwordHash);
        }
    }

    public static class Sesion implements SesionContexto {

        private SesionIniciadaResponse actual;

        @Override
        public void iniciar(SesionIniciadaResponse sesion) {
            actual = sesion;
        }

        @Override
        public void cerrar() {
            actual = null;
        }

        @Override
        public Optional<SesionIniciadaResponse> obtenerActual() {
            return Optional.ofNullable(actual);
        }
    }

    /** Registro de sesiones activas: una por cuenta, como la clave primaria de la tabla real. */
    public static class Sesiones implements SesionRepository {

        public final java.util.Map<Long, String> activas = new java.util.HashMap<>();
        public final List<Long> latidos = new ArrayList<>();

        @Override
        public boolean registrar(Long usuarioId, String token) {
            return activas.putIfAbsent(usuarioId, token) == null;
        }

        @Override
        public void latido(Long usuarioId, String token) {
            if (token.equals(activas.get(usuarioId))) {
                latidos.add(usuarioId);
            }
        }

        @Override
        public void eliminar(Long usuarioId, String token) {
            activas.remove(usuarioId, token);
        }
    }

    public static class TransaccionesGuardadas implements TransaccionRepository {

        public final List<Transaccion> guardadas = new ArrayList<>();

        @Override
        public Optional<Transaccion> guardar(Transaccion transaccion) {
            transaccion.setId((long) guardadas.size() + 1);
            transaccion.setFecha(OffsetDateTime.now());
            guardadas.add(transaccion);
            return Optional.of(transaccion);
        }
    }

    public static class Movimientos implements MovimientoRepository {

        public final List<Movimiento> guardados = new ArrayList<>();

        @Override
        public Optional<Movimiento> guardar(Movimiento movimiento) {
            movimiento.setId((long) guardados.size() + 1);
            guardados.add(movimiento);
            return Optional.of(movimiento);
        }
    }

    public static class Tipos implements TipoTransaccionRepository {

        public static final long RETIRO = 2;
        public static final long TRANSFERENCIA = 3;
        public static final long PAGO_CREDITO = 5;
        public static final long DESEMBOLSO_CREDITO = 6;

        private final Map<String, Long> porCodigo = Map.of(
                "RETIRO", RETIRO,
                "TRANSFERENCIA", TRANSFERENCIA,
                "PAGO_CREDITO", PAGO_CREDITO,
                "DESEMBOLSO_CREDITO", DESEMBOLSO_CREDITO);

        @Override
        public Optional<Long> findIdByCodigo(String codigo) {
            return Optional.ofNullable(porCodigo.get(codigo));
        }
    }

    public static class Productos implements ProductoRepository {

        private final List<ProductoCrediticio> productos = new ArrayList<>();

        public Productos con(long id, TipoProductoCrediticio tipo, String montoMinimo, String montoMaximo,
                             int plazoMinimo, int plazoMaximo, String tea) {
            productos.add(new ProductoCrediticio(id, tipo.name(), new BigDecimal(montoMinimo),
                    new BigDecimal(montoMaximo), tipo, plazoMinimo, plazoMaximo, new BigDecimal(tea)));
            return this;
        }

        @Override
        public List<ProductoCrediticio> listar() {
            return List.copyOf(productos);
        }

        @Override
        public Optional<ProductoCrediticio> findById(Long id) {
            return productos.stream().filter(producto -> producto.getId().equals(id)).findFirst();
        }
    }

    public static class Historial implements HistorialCrediticioQuery {

        public boolean enMora;
        public final Set<TipoProductoCrediticio> activos = EnumSet.noneOf(TipoProductoCrediticio.class);
        public final Set<TipoProductoCrediticio> pagados = EnumSet.noneOf(TipoProductoCrediticio.class);

        @Override
        public boolean tienePrestamoEnMora(Long clienteId) {
            return enMora;
        }

        @Override
        public boolean tienePrestamoActivo(Long clienteId, TipoProductoCrediticio tipo) {
            return activos.contains(tipo);
        }

        @Override
        public boolean tienePrestamoPagado(Long clienteId, TipoProductoCrediticio tipo) {
            return pagados.contains(tipo);
        }
    }

    public static class Solicitudes implements SolicitudCreditoRepository {

        public final List<SolicitudCredito> guardadas = new ArrayList<>();

        @Override
        public Optional<SolicitudCredito> guardar(SolicitudCredito solicitud) {
            solicitud.setId((long) guardadas.size() + 1);
            guardadas.add(solicitud);
            return Optional.of(solicitud);
        }
    }

    public static class Prestamos implements PrestamoRepository, PrestamoQuery {

        public final Map<Long, Prestamo> porId = new LinkedHashMap<>();
        private final Map<Long, Long> duenios = new HashMap<>();

        public Prestamos con(Prestamo prestamo, long clienteId) {
            porId.put(prestamo.getId(), prestamo);
            duenios.put(prestamo.getId(), clienteId);
            return this;
        }

        @Override
        public Optional<Prestamo> guardar(Prestamo prestamo) {
            prestamo.setId((long) porId.size() + 1);
            prestamo.setFechaDesembolso(OffsetDateTime.now());
            porId.put(prestamo.getId(), prestamo);
            return Optional.of(prestamo);
        }

        @Override
        public Optional<Prestamo> findByIdParaActualizar(Long id) {
            return Optional.ofNullable(porId.get(id));
        }

        @Override
        public void actualizar(Prestamo prestamo) {
            porId.put(prestamo.getId(), prestamo);
        }

        @Override
        public List<PrestamoResumenResponse> buscarPorClienteId(Long clienteId) {
            return List.of();
        }

        @Override
        public Optional<Long> buscarClienteIdDelPrestamo(Long prestamoId) {
            return Optional.ofNullable(duenios.get(prestamoId));
        }

        @Override
        public List<CuotaCronogramaResponse> buscarCuotas(Long prestamoId) {
            return List.of();
        }
    }

    public static class Cuotas implements CuotaRepository {

        public final List<Cuota> guardadas = new ArrayList<>();

        public Cuotas con(long prestamoId, int numero, String capital, String interes, String mora, EstadoCuota estado) {
            guardadas.add(new Cuota((long) guardadas.size() + 1, prestamoId, numero, LocalDate.of(2026, 11, 1),
                    new BigDecimal(capital), new BigDecimal(interes), new BigDecimal(mora), estado));
            return this;
        }

        public Cuota numero(int numero) {
            return guardadas.stream().filter(cuota -> cuota.getNumero() == numero).findFirst().orElseThrow();
        }

        @Override
        public void guardarTodas(List<Cuota> cuotas) {
            guardadas.addAll(cuotas);
        }

        @Override
        public Optional<Cuota> buscarPrimeraNoPagadaParaActualizar(Long prestamoId) {
            return guardadas.stream()
                    .filter(cuota -> cuota.getPrestamoId().equals(prestamoId) && cuota.getEstado() != EstadoCuota.PAGADA)
                    .min(Comparator.comparing(Cuota::getNumero));
        }

        @Override
        public void actualizarEstado(Cuota cuota) {
            // El servicio modifica la misma instancia que está en la lista.
        }

        @Override
        public boolean existeNoPagada(Long prestamoId) {
            return guardadas.stream()
                    .anyMatch(cuota -> cuota.getPrestamoId().equals(prestamoId) && cuota.getEstado() != EstadoCuota.PAGADA);
        }

        @Override
        public boolean existeVencida(Long prestamoId) {
            return guardadas.stream()
                    .anyMatch(cuota -> cuota.getPrestamoId().equals(prestamoId) && cuota.getEstado() == EstadoCuota.VENCIDA);
        }
    }

    public static class Pagos implements PagoRepository {

        public final List<Pago> guardados = new ArrayList<>();
        public final List<PagoDetalle> detalles = new ArrayList<>();

        @Override
        public Optional<Pago> guardar(Pago pago) {
            pago.setId((long) guardados.size() + 1);
            guardados.add(pago);
            return Optional.of(pago);
        }

        @Override
        public void guardarDetalle(PagoDetalle detalle) {
            detalles.add(detalle);
        }
    }
}
