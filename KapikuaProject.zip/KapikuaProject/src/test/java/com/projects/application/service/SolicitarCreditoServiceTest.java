package com.projects.application.service;

import com.projects.application.dto.command.SolicitarCreditoCommand;
import com.projects.application.service.support.CalculadoraCronograma;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.model.EstadoCuota;
import com.projects.domain.model.EstadoPrestamo;
import com.projects.domain.model.EstadoSolicitudCredito;
import com.projects.domain.model.TipoProductoCrediticio;
import com.projects.domain.model.credito.Cuota;
import com.projects.domain.result.BilleteraError;
import com.projects.domain.result.CreditoError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SolicitarCreditoServiceTest {

    private static final long ANA = 1;
    private static final long BILLETERA_ANA = 11;
    private static final long PERSONAL = 1;
    private static final long MICRO = 2;

    private EnMemoria.Billeteras billeteras;
    private EnMemoria.Historial historial;
    private EnMemoria.Solicitudes solicitudes;
    private EnMemoria.Prestamos prestamos;
    private EnMemoria.Cuotas cuotas;
    private EnMemoria.TransaccionesGuardadas transacciones;
    private EnMemoria.Movimientos movimientos;
    private SolicitarCreditoService servicio;

    @BeforeEach
    void preparar() {
        prepararCon(EstadoBilletera.ACTIVA);
    }

    private void prepararCon(EstadoBilletera estado) {
        var productos = new EnMemoria.Productos()
                .con(PERSONAL, TipoProductoCrediticio.CREDITO_PERSONAL, "500.00", "20000.00", 3, 36, "45.00")
                .con(MICRO, TipoProductoCrediticio.MICROCREDITO, "100.00", "3000.00", 1, 12, "60.00");
        billeteras = new EnMemoria.Billeteras().con(BILLETERA_ANA, ANA, "50.00", estado);
        historial = new EnMemoria.Historial();
        solicitudes = new EnMemoria.Solicitudes();
        prestamos = new EnMemoria.Prestamos();
        cuotas = new EnMemoria.Cuotas();
        transacciones = new EnMemoria.TransaccionesGuardadas();
        movimientos = new EnMemoria.Movimientos();
        servicio = new SolicitarCreditoService(productos, billeteras, historial, solicitudes, prestamos, cuotas,
                transacciones, movimientos, new EnMemoria.Tipos(), new EnMemoria.Transacciones(), new CalculadoraCronograma());
    }

    private SolicitarCreditoCommand solicitud(long productoId, String monto, int plazo) {
        return new SolicitarCreditoCommand(ANA, productoId, new BigDecimal(monto), plazo);
    }

    private void assertNoHuboDesembolso() {
        assertMonto("50.00", billeteras.saldoDe(BILLETERA_ANA));
        assertTrue(prestamos.porId.isEmpty());
        assertTrue(cuotas.guardadas.isEmpty());
        assertTrue(transacciones.guardadas.isEmpty());
    }

    @Test
    void unMicrocreditoAprobadoSeDesembolsaEnLaBilletera() {
        var respuesta = servicio.ejecutar(solicitud(MICRO, "1000.00", 6)).getValue().orElseThrow();

        assertTrue(respuesta.aprobada());
        assertMonto("1050.00", billeteras.saldoDe(BILLETERA_ANA));
        assertMonto("1050.00", respuesta.saldoResultante());
        assertEquals(EstadoSolicitudCredito.APROBADA, solicitudes.guardadas.get(0).getEstado());

        var transaccion = transacciones.guardadas.get(0);
        assertEquals(EnMemoria.Tipos.DESEMBOLSO_CREDITO, transaccion.getTipoId());
        assertEquals('+', movimientos.guardados.get(0).getSigno());
        assertMonto("1050.00", movimientos.guardados.get(0).getSaldoPosterior());
    }

    @Test
    void elPrestamoNaceActivoConTodoElCapitalPendiente() {
        servicio.ejecutar(solicitud(MICRO, "1000.00", 6));

        var prestamo = prestamos.porId.get(1L);
        assertEquals(EstadoPrestamo.ACTIVO, prestamo.getEstado());
        assertMonto("1000.00", prestamo.getMontoDesembolsado());
        assertMonto("1000.00", prestamo.getSaldoCapital());
        assertMonto("60.00", prestamo.getTcea());
    }

    @Test
    void seGuardaUnaCuotaPorMesYElCapitalSumaElMontoPrestado() {
        servicio.ejecutar(solicitud(MICRO, "1000.00", 6));

        assertEquals(6, cuotas.guardadas.size());
        assertTrue(cuotas.guardadas.stream().allMatch(cuota -> cuota.getEstado() == EstadoCuota.PENDIENTE));
        assertMonto("1000.00", cuotas.guardadas.stream().map(Cuota::getCapital).reduce(BigDecimal.ZERO, BigDecimal::add));
        assertMonto("0", cuotas.guardadas.stream().map(Cuota::getMora).reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    // Una solicitud rechazada es un resultado válido: se guarda con su motivo y no mueve dinero.
    @Test
    void elCreditoPersonalExigeUnMicrocreditoPagado() {
        var respuesta = servicio.ejecutar(solicitud(PERSONAL, "5000.00", 12)).getValue().orElseThrow();

        assertFalse(respuesta.aprobada());
        assertEquals(CreditoError.REQUIERE_MICROCREDITO_PAGADO.name(), respuesta.motivoRechazo());
        assertNull(respuesta.prestamoId());
        assertEquals(EstadoSolicitudCredito.RECHAZADA, solicitudes.guardadas.get(0).getEstado());
        assertNoHuboDesembolso();
    }

    @Test
    void conUnMicrocreditoPagadoSeApruebaElCreditoPersonal() {
        historial.pagados.add(TipoProductoCrediticio.MICROCREDITO);

        var respuesta = servicio.ejecutar(solicitud(PERSONAL, "5000.00", 12)).getValue().orElseThrow();

        assertTrue(respuesta.aprobada());
        assertMonto("5050.00", billeteras.saldoDe(BILLETERA_ANA));
    }

    @Test
    void unClienteEnMoraNoRecibeOtroCredito() {
        historial.enMora = true;

        var respuesta = servicio.ejecutar(solicitud(MICRO, "1000.00", 6)).getValue().orElseThrow();

        assertEquals(CreditoError.PRESTAMO_EN_MORA.name(), respuesta.motivoRechazo());
        assertNoHuboDesembolso();
    }

    @Test
    void noSeAcumulanDosPrestamosActivosDelMismoTipo() {
        historial.activos.add(TipoProductoCrediticio.MICROCREDITO);

        var respuesta = servicio.ejecutar(solicitud(MICRO, "1000.00", 6)).getValue().orElseThrow();

        assertEquals(CreditoError.LIMITE_PRESTAMOS.name(), respuesta.motivoRechazo());
        assertNoHuboDesembolso();
    }

    @Test
    void elMontoYElPlazoDebenEstarDentroDelProducto() {
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), codigo(servicio.ejecutar(solicitud(MICRO, "3000.01", 6))));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), codigo(servicio.ejecutar(solicitud(MICRO, "99.99", 6))));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), codigo(servicio.ejecutar(solicitud(MICRO, "-1000", 6))));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), codigo(servicio.ejecutar(solicitud(MICRO, "1000", 13))));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), codigo(servicio.ejecutar(solicitud(MICRO, "1000.005", 6))));
        assertEquals(CreditoError.PRODUCTO_NO_ENCONTRADO.name(), codigo(servicio.ejecutar(solicitud(99, "1000", 6))));

        assertTrue(solicitudes.guardadas.isEmpty());
        assertNoHuboDesembolso();
    }

    @Test
    void unaBilleteraBloqueadaNoRecibeDesembolsos() {
        prepararCon(EstadoBilletera.BLOQUEADA);

        var resultado = servicio.ejecutar(solicitud(MICRO, "1000.00", 6));

        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(), codigo(resultado));
        assertMonto("50.00", billeteras.saldoDe(BILLETERA_ANA));
        assertTrue(transacciones.guardadas.isEmpty());
    }
}
