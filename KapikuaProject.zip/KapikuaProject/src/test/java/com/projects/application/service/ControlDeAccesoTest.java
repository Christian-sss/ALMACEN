package com.projects.application.service;

import com.projects.application.dto.command.ConsultarCronogramaCommand;
import com.projects.application.dto.command.ConsultarEstadisticasCommand;
import com.projects.application.dto.command.GenerarComprobanteCommand;
import com.projects.application.dto.command.PeriodoEstadistica;
import com.projects.application.dto.response.ComprobanteFilaResponse;
import com.projects.application.dto.response.ComprobanteResponse;
import com.projects.application.dto.response.EstadisticasResponse;
import com.projects.application.dto.response.SesionIniciadaResponse;
import com.projects.application.port.out.ComprobanteQuery;
import com.projects.application.port.out.ReportePdfPort;
import com.projects.domain.model.EstadoPrestamo;
import com.projects.domain.model.credito.Prestamo;
import com.projects.domain.result.CreditoError;
import com.projects.domain.result.TransaccionError;
import com.projects.domain.result.UsuarioError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Quién puede ver qué: comprobantes y cronogramas solo para sus dueños, estadísticas solo para ADMIN.
 */
class ControlDeAccesoTest {

    private static final long ANA = 1;
    private static final long LUIS = 2;
    private static final long TERCERO = 3;
    private static final long TRANSFERENCIA = 40;

    private final List<ComprobanteResponse> comprobantesGenerados = new ArrayList<>();

    private final ReportePdfPort pdf = new ReportePdfPort() {
        @Override
        public byte[] generarComprobante(ComprobanteResponse comprobante) {
            comprobantesGenerados.add(comprobante);
            return new byte[]{'%', 'P', 'D', 'F'};
        }

        @Override
        public byte[] generarReporteEstadisticas(EstadisticasResponse estadisticas) {
            return new byte[]{'%', 'P', 'D', 'F'};
        }
    };

    // Transferencia de Ana (queda con 69.50) a Luis (queda con 80.50).
    private final ComprobanteQuery comprobantes = transaccionId -> transaccionId != TRANSFERENCIA ? List.of() : List.of(
            fila(ANA, "Ana", "Torres", '-', "69.50"),
            fila(LUIS, "Luis", "Garcia", '+', "80.50"));

    private static ComprobanteFilaResponse fila(long clienteId, String nombres, String apellidos, char signo, String saldo) {
        return new ComprobanteFilaResponse(TRANSFERENCIA, OffsetDateTime.now(), "TRANSFERENCIA", new BigDecimal("30.50"),
                "EXITOSA", null, clienteId, nombres, apellidos, signo, new BigDecimal(saldo));
    }

    @Test
    void elComprobanteSoloLoObtienenQuienesParticiparonEnLaTransaccion() {
        var servicio = new GenerarComprobanteService(comprobantes, pdf);

        assertTrue(servicio.ejecutar(new GenerarComprobanteCommand(TRANSFERENCIA, ANA)).isSuccess());
        assertTrue(servicio.ejecutar(new GenerarComprobanteCommand(TRANSFERENCIA, LUIS)).isSuccess());

        var resultado = servicio.ejecutar(new GenerarComprobanteCommand(TRANSFERENCIA, TERCERO));
        assertEquals(TransaccionError.SIN_PERMISO.name(), codigo(resultado));
        assertEquals(2, comprobantesGenerados.size());
    }

    // Quien recibe la transferencia no debe ver el saldo de quien la envió.
    @Test
    void elComprobanteSoloMuestraElSaldoDeQuienLoPide() {
        var servicio = new GenerarComprobanteService(comprobantes, pdf);

        servicio.ejecutar(new GenerarComprobanteCommand(TRANSFERENCIA, LUIS));

        var comprobante = comprobantesGenerados.get(0);
        assertMonto("80.50", comprobante.saldoResultanteSolicitante());
        assertEquals("Ana Torres", comprobante.origenNombre());
        assertEquals("Luis Garcia", comprobante.destinoNombre());
    }

    @Test
    void unaTransaccionInexistenteNoGeneraComprobante() {
        var servicio = new GenerarComprobanteService(comprobantes, pdf);

        assertEquals(TransaccionError.TRANSACCION_NO_ENCONTRADA.name(),
                codigo(servicio.ejecutar(new GenerarComprobanteCommand(999L, ANA))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new GenerarComprobanteCommand(TRANSFERENCIA, null))));
    }

    @Test
    void elCronogramaSoloLoVeElDuenoDelPrestamo() {
        var prestamos = new EnMemoria.Prestamos().con(new Prestamo(7L, 70L, new BigDecimal("340.00"),
                new BigDecimal("40.00"), new BigDecimal("340.00"), EstadoPrestamo.ACTIVO, OffsetDateTime.now()), ANA);
        var servicio = new ConsultarCronogramaService(prestamos);

        assertTrue(servicio.ejecutar(new ConsultarCronogramaCommand(ANA, 7L)).isSuccess());
        assertEquals(CreditoError.SIN_PERMISO.name(), codigo(servicio.ejecutar(new ConsultarCronogramaCommand(LUIS, 7L))));
        assertEquals(CreditoError.PRESTAMO_NO_ENCONTRADO.name(), codigo(servicio.ejecutar(new ConsultarCronogramaCommand(ANA, 999L))));
    }

    // El puerto de consulta es null a propósito: la verificación de rol debe cortar antes de leer datos.
    @Test
    void lasEstadisticasSonSoloParaAdministradores() {
        var sesion = new EnMemoria.Sesion();
        var servicio = new ConsultarEstadisticasService(null, sesion);
        var comando = new ConsultarEstadisticasCommand(PeriodoEstadistica.DIA);

        assertEquals(UsuarioError.ACCESO_DENEGADO.name(), codigo(servicio.ejecutar(comando)));

        sesion.iniciar(new SesionIniciadaResponse(1L, "ana@gmail.com", 1L, "CLIENTE"));
        assertEquals(UsuarioError.ACCESO_DENEGADO.name(), codigo(servicio.ejecutar(comando)));
    }

    @Test
    void elReportePdfHeredaLaRestriccionDeAdministrador() {
        var sesion = new EnMemoria.Sesion();
        sesion.iniciar(new SesionIniciadaResponse(1L, "ana@gmail.com", 1L, "CLIENTE"));
        var servicio = new GenerarReporteEstadisticasService(new ConsultarEstadisticasService(null, sesion), pdf);

        assertEquals(UsuarioError.ACCESO_DENEGADO.name(),
                codigo(servicio.ejecutar(new ConsultarEstadisticasCommand(PeriodoEstadistica.MES))));
    }

    @Test
    void alCerrarSesionSePierdeElAccesoDeAdministrador() {
        var sesion = new EnMemoria.Sesion();
        sesion.iniciar(new SesionIniciadaResponse(2L, "admin@upt.pe", 2L, "ADMIN"));

        new CerrarSesionService(sesion, new EnMemoria.Sesiones()).cerrarSesion();

        assertTrue(sesion.obtenerActual().isEmpty());
        assertEquals(UsuarioError.ACCESO_DENEGADO.name(),
                codigo(new ConsultarEstadisticasService(null, sesion).ejecutar(new ConsultarEstadisticasCommand(PeriodoEstadistica.DIA))));
    }
}
