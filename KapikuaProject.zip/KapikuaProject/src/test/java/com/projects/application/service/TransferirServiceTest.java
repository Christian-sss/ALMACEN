package com.projects.application.service;

import com.projects.application.dto.command.TransferirMontoCommand;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.result.BilleteraError;
import com.projects.domain.result.ClienteError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TransferirServiceTest {

    private static final long ANA = 1;
    private static final long LUIS = 2;
    private static final long BILLETERA_ANA = 11;
    private static final long BILLETERA_LUIS = 22;
    private static final String CELULAR_ANA = "951753468";
    private static final String CELULAR_LUIS = "962847135";

    private EnMemoria.Billeteras billeteras;
    private EnMemoria.TransaccionesGuardadas transacciones;
    private EnMemoria.Movimientos movimientos;
    private TransferirService servicio;

    @BeforeEach
    void preparar() {
        prepararCon(EstadoBilletera.ACTIVA, EstadoBilletera.ACTIVA);
    }

    private void prepararCon(EstadoBilletera estadoAna, EstadoBilletera estadoLuis) {
        billeteras = new EnMemoria.Billeteras()
                .con(BILLETERA_ANA, ANA, "100.00", estadoAna)
                .con(BILLETERA_LUIS, LUIS, "50.00", estadoLuis);
        var clientes = new EnMemoria.Clientes()
                .con(ANA, 1, "Ana María", "Torres", "45871236", CELULAR_ANA)
                .con(LUIS, 2, "Luis", "Garcia Mendoza", "45871237", CELULAR_LUIS);
        transacciones = new EnMemoria.TransaccionesGuardadas();
        movimientos = new EnMemoria.Movimientos();
        servicio = new TransferirService(billeteras, clientes, transacciones, movimientos,
                new EnMemoria.Tipos(), new EnMemoria.Transacciones());
    }

    private void assertNadaCambio() {
        assertMonto("100.00", billeteras.saldoDe(BILLETERA_ANA));
        assertMonto("50.00", billeteras.saldoDe(BILLETERA_LUIS));
        assertTrue(transacciones.guardadas.isEmpty());
        assertTrue(movimientos.guardados.isEmpty());
    }

    @Test
    void debitaAlOrigenYAcreditaAlDestino() {
        var respuesta = servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("30.50")))
                .getValue().orElseThrow();

        assertMonto("69.50", billeteras.saldoDe(BILLETERA_ANA));
        assertMonto("80.50", billeteras.saldoDe(BILLETERA_LUIS));
        assertMonto("69.50", respuesta.saldoResultante());
        assertEquals("Luis G***", respuesta.destinatarioNombreEnmascarado());
    }

    // RF del diseño: una sola transacción con dos movimientos, uno por billetera.
    @Test
    void registraUnaTransaccionConDosMovimientos() {
        servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("30.50")));

        assertEquals(1, transacciones.guardadas.size());
        assertEquals(EnMemoria.Tipos.TRANSFERENCIA, transacciones.guardadas.get(0).getTipoId());
        assertMonto("30.50", transacciones.guardadas.get(0).getMonto());

        assertEquals(2, movimientos.guardados.size());
        var salida = movimientos.guardados.get(0);
        var entrada = movimientos.guardados.get(1);
        assertEquals('-', salida.getSigno());
        assertEquals(BILLETERA_ANA, salida.getBilleteraId());
        assertMonto("69.50", salida.getSaldoPosterior());
        assertEquals('+', entrada.getSigno());
        assertEquals(BILLETERA_LUIS, entrada.getBilleteraId());
        assertMonto("80.50", entrada.getSaldoPosterior());
    }

    @Test
    void permiteTransferirTodoElSaldo() {
        assertTrue(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("100.00"))).isSuccess());
        assertMonto("0", billeteras.saldoDe(BILLETERA_ANA));
        assertMonto("150.00", billeteras.saldoDe(BILLETERA_LUIS));
    }

    @Test
    void rechazaSiElSaldoNoAlcanza() {
        var resultado = servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("100.01")));

        assertEquals(BilleteraError.SALDO_INSUFICIENTE.name(), codigo(resultado));
        assertNadaCambio();
    }

    @Test
    void rechazaMontosCeroONegativos() {
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(),
                codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, BigDecimal.ZERO))));
        // Un monto negativo invertiría la transferencia: le quitaría dinero al destinatario.
        assertEquals(BilleteraError.AMOUNT_NEGATIVE.name(),
                codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("-50")))));
        assertNadaCambio();
    }

    @Test
    void noPermiteTransferirseAUnoMismo() {
        var resultado = servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_ANA, new BigDecimal("10")));

        assertEquals(ClienteError.DESTINATARIO_INVALIDO.name(), codigo(resultado));
        assertNadaCambio();
    }

    @Test
    void rechazaUnCelularQueNoEsCliente() {
        var resultado = servicio.ejecutar(new TransferirMontoCommand(ANA, "900000001", new BigDecimal("10")));

        assertEquals(ClienteError.DESTINATARIO_NO_ENCONTRADO.name(), codigo(resultado));
        assertNadaCambio();
    }

    @Test
    void unaBilleteraBloqueadaNoEnviaNiRecibe() {
        prepararCon(EstadoBilletera.BLOQUEADA, EstadoBilletera.ACTIVA);
        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(),
                codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("10")))));
        assertNadaCambio();

        prepararCon(EstadoBilletera.ACTIVA, EstadoBilletera.BLOQUEADA);
        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(),
                codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("10")))));
        assertNadaCambio();
    }

    @Test
    void exigeTodosLosDatosDelComando() {
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(null)));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new TransferirMontoCommand(null, CELULAR_LUIS, BigDecimal.TEN))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, "  ", BigDecimal.TEN))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, null))));
    }

    @Disabled("HALLAZGO H1: el servicio acepta montos con más de 2 decimales. Con saldo NUMERIC(12,2), "
            + "99.995 se guarda como 100.00 y 50.005 como 50.01: cada transferencia de 0.005 crea S/ 0.01.")
    @Test
    void unMontoConMasDeDosDecimalesNoPuedeCrearDinero() {
        var resultado = servicio.ejecutar(new TransferirMontoCommand(ANA, CELULAR_LUIS, new BigDecimal("0.005")));

        assertMonto("150.00", billeteras.saldoDe(BILLETERA_ANA).add(billeteras.saldoDe(BILLETERA_LUIS)));
        assertTrue(resultado.isFailure());
    }
}
