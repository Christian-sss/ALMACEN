package com.projects.application.service;

import com.projects.application.dto.command.IniciarSesionCommand;
import com.projects.domain.result.UsuarioError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IniciarSesionServiceTest {

    private EnMemoria.Sesion sesion;
    private EnMemoria.Sesiones sesiones;
    private IniciarSesionService servicio;

    @BeforeEach
    void preparar() {
        var usuarios = new EnMemoria.Usuarios()
                .con(1, EnMemoria.Roles.CLIENTE, "ana@gmail.com", "hash(Secreta1)", true)
                .con(2, EnMemoria.Roles.ADMIN, "admin@upt.pe", "hash(Admin2026)", true)
                .con(3, EnMemoria.Roles.CLIENTE, "baja@gmail.com", "hash(Secreta1)", false);
        sesion = new EnMemoria.Sesion();
        sesiones = new EnMemoria.Sesiones();
        servicio = new IniciarSesionService(usuarios, new EnMemoria.Roles(), new EnMemoria.Hasher(), sesion, sesiones);
    }

    @Test
    void conCredencialesCorrectasAbreLaSesion() {
        var respuesta = servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1")).getValue().orElseThrow();

        assertEquals(1L, respuesta.usuarioId());
        assertEquals("CLIENTE", respuesta.rol());
        assertFalse(respuesta.esAdmin());
        assertEquals(respuesta, sesion.obtenerActual().orElseThrow());
    }

    @Test
    void elEmailNoDistingueMayusculasNiEspacios() {
        assertTrue(servicio.iniciarSesion(new IniciarSesionCommand("  ANA@Gmail.com ", "Secreta1")).isSuccess());
    }

    @Test
    void laContrasenaSiDistingueMayusculasYEspacios() {
        assertEquals(UsuarioError.CREDENCIALES_INVALIDAS.name(),
                codigo(servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "secreta1"))));
        assertEquals(UsuarioError.CREDENCIALES_INVALIDAS.name(),
                codigo(servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1 "))));
        assertTrue(sesion.obtenerActual().isEmpty());
    }

    // No se revela si el correo existe: mismo código y mismo mensaje en ambos casos.
    @Test
    void elErrorEsIdenticoSiElEmailNoExisteOSiLaContrasenaEsIncorrecta() {
        var emailInexistente = servicio.iniciarSesion(new IniciarSesionCommand("nadie@gmail.com", "Secreta1"));
        var contrasenaIncorrecta = servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "otra"));

        assertEquals(UsuarioError.CREDENCIALES_INVALIDAS.name(), codigo(emailInexistente));
        assertEquals(emailInexistente.getError(), contrasenaIncorrecta.getError());
        assertTrue(sesion.obtenerActual().isEmpty());
    }

    @Test
    void unUsuarioInactivoNoEntra() {
        var resultado = servicio.iniciarSesion(new IniciarSesionCommand("baja@gmail.com", "Secreta1"));

        assertEquals(UsuarioError.USUARIO_INACTIVO.name(), codigo(resultado));
        assertTrue(sesion.obtenerActual().isEmpty());
    }

    // El estado de la cuenta solo se revela a quien conoce la contraseña.
    @Test
    void unUsuarioInactivoConContrasenaIncorrectaRecibeElErrorGenerico() {
        var resultado = servicio.iniciarSesion(new IniciarSesionCommand("baja@gmail.com", "otra"));

        assertEquals(UsuarioError.CREDENCIALES_INVALIDAS.name(), codigo(resultado));
    }

    @Test
    void elRolAdminSeReflejaEnLaSesion() {
        var respuesta = servicio.iniciarSesion(new IniciarSesionCommand("admin@upt.pe", "Admin2026")).getValue().orElseThrow();

        assertTrue(respuesta.esAdmin());
    }

    @Test
    void exigeEmailYContrasena() {
        assertEquals("COMANDO_INVALIDO", codigo(servicio.iniciarSesion(null)));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.iniciarSesion(new IniciarSesionCommand("  ", "Secreta1"))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", ""))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.iniciarSesion(new IniciarSesionCommand(null, null))));
    }

    // Con PreparedStatement el texto viaja como parámetro: una inyección es solo un email que no existe.
    @Test
    void unIntentoDeInyeccionSqlEsSoloUnEmailInexistente() {
        var resultado = servicio.iniciarSesion(new IniciarSesionCommand("' OR '1'='1' --", "' OR '1'='1"));

        assertEquals(UsuarioError.CREDENCIALES_INVALIDAS.name(), codigo(resultado));
        assertTrue(sesion.obtenerActual().isEmpty());
    }

    @Test
    void alIniciarSesionSeRegistraUnaSesionConSuToken() {
        var respuesta = servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1")).getValue().orElseThrow();

        assertEquals(respuesta.token(), sesiones.activas.get(1L));
    }

    // Simula abrir la misma cuenta desde otra instancia (IntelliJ + NetBeans) con otro registro local.
    @Test
    void unaCuentaConSesionAbiertaNoPuedeIniciarOtra() {
        servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1"));
        var otraInstancia = new IniciarSesionService(
                new EnMemoria.Usuarios().con(1, EnMemoria.Roles.CLIENTE, "ana@gmail.com", "hash(Secreta1)", true),
                new EnMemoria.Roles(), new EnMemoria.Hasher(), new EnMemoria.Sesion(), sesiones);

        var resultado = otraInstancia.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1"));

        assertEquals(UsuarioError.SESION_YA_ACTIVA.name(), codigo(resultado));
    }

    @Test
    void otraCuentaSiPuedeIniciarSesionAlMismoTiempo() {
        assertTrue(servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1")).isSuccess());
        assertTrue(servicio.iniciarSesion(new IniciarSesionCommand("admin@upt.pe", "Admin2026")).isSuccess());
    }

    @Test
    void conCredencialesInvalidasNoSeRegistraNingunaSesion() {
        servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "mala"));
        servicio.iniciarSesion(new IniciarSesionCommand("baja@gmail.com", "Secreta1"));

        assertTrue(sesiones.activas.isEmpty());
    }

    @Test
    void siLaCuentaYaEstabaEnUsoNoSeAbreSesionLocal() {
        sesiones.registrar(1L, "token-de-otra-instancia");

        servicio.iniciarSesion(new IniciarSesionCommand("ana@gmail.com", "Secreta1"));

        assertTrue(sesion.obtenerActual().isEmpty());
        assertEquals("token-de-otra-instancia", sesiones.activas.get(1L));
    }
}
