package com.projects.application.service;

import com.projects.application.dto.command.RegistrarClienteCommand;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.result.ClienteError;
import com.projects.domain.result.UsuarioError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RegistroClienteServiceTest {

    private static final LocalDate NACIMIENTO = LocalDate.of(2000, 3, 15);

    private EnMemoria.Usuarios usuarios;
    private EnMemoria.Clientes clientes;
    private EnMemoria.Billeteras billeteras;
    private RegistroClienteService servicio;

    @BeforeEach
    void preparar() {
        usuarios = new EnMemoria.Usuarios().con(1, EnMemoria.Roles.CLIENTE, "luis@gmail.com", "hash(x)", true);
        clientes = new EnMemoria.Clientes().con(1, 1, "Luis", "Garcia", "45871237", "962847135");
        billeteras = new EnMemoria.Billeteras().con(1, 1, "350.00", EstadoBilletera.ACTIVA);
        servicio = new RegistroClienteService(usuarios, clientes, new EnMemoria.Hasher(), billeteras,
                new EnMemoria.Roles(), new EnMemoria.Transacciones());
    }

    private static RegistrarClienteCommand comando(String email, String password, String dni, String celular, LocalDate nacimiento) {
        return new RegistrarClienteCommand(email, password, "Ana María", "Torres Flores", dni, celular, nacimiento);
    }

    private void assertNoSeRegistroNada() {
        assertEquals(1, usuarios.guardados.size());
        assertEquals(1, clientes.guardados.size());
        assertEquals(1, billeteras.total());
    }

    @Test
    void creaUsuarioClienteYBilleteraEnCero() {
        var respuesta = servicio.ejecutar(comando("Ana@Gmail.com", "Secreta1", "45871236", "951753468", NACIMIENTO))
                .getValue().orElseThrow();

        assertEquals("ana@gmail.com", respuesta.email());

        var usuario = usuarios.findByEmail("ana@gmail.com").orElseThrow();
        assertEquals(EnMemoria.Roles.CLIENTE, usuario.getRolId());
        assertTrue(usuario.getActivo());

        var cliente = clientes.findByUsuarioId(usuario.getId()).orElseThrow();
        assertEquals(respuesta.clienteId(), cliente.getId());
        assertEquals("45871236", cliente.getDni());

        var billetera = billeteras.findByClienteId(cliente.getId()).orElseThrow();
        assertMonto("0", billetera.getSaldo());
        assertEquals(EstadoBilletera.ACTIVA, billetera.getEstadoBilletera());
    }

    @Test
    void laContrasenaNuncaSeGuardaEnTextoPlano() {
        servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "45871236", "951753468", NACIMIENTO));

        var usuario = usuarios.findByEmail("ana@gmail.com").orElseThrow();
        assertNotEquals("Secreta1", usuario.getPasswordHash());
        assertEquals("hash(Secreta1)", usuario.getPasswordHash());
    }

    @Test
    void elEmailNoSePuedeRepetirAunqueCambienLasMayusculas() {
        var resultado = servicio.ejecutar(comando("LUIS@gmail.com", "Secreta1", "45871236", "951753468", NACIMIENTO));

        assertEquals(UsuarioError.EMAIL_DUPLICADO.name(), codigo(resultado));
        assertNoSeRegistroNada();
    }

    @Test
    void elDniNoSePuedeRepetir() {
        var resultado = servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "45871237", "951753468", NACIMIENTO));

        assertEquals(ClienteError.DNI_DUPLICADO.name(), codigo(resultado));
        assertNoSeRegistroNada();
    }

    @Test
    void elCelularNoSePuedeRepetir() {
        var resultado = servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "45871236", "962847135", NACIMIENTO));

        assertEquals(ClienteError.CELULAR_DUPLICADO.name(), codigo(resultado));
        assertNoSeRegistroNada();
    }

    @Test
    void unMenorDeEdadNoSeRegistra() {
        var resultado = servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "45871236", "951753468",
                LocalDate.now().minusYears(17)));

        assertEquals(ClienteError.MENOR_DE_EDAD.name(), codigo(resultado));
        assertNoSeRegistroNada();
    }

    @Test
    void validaLosDatosAntesDeTocarLaBaseDeDatos() {
        assertEquals(UsuarioError.EMAIL_DOMINIO_NO_PERMITIDO.name(),
                codigo(servicio.ejecutar(comando("ana@yahoo.com", "Secreta1", "45871236", "951753468", NACIMIENTO))));
        assertEquals(ClienteError.DNI_INVALIDO.name(),
                codigo(servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "4587123", "951753468", NACIMIENTO))));
        assertEquals(ClienteError.CELULAR_INVALIDO.name(),
                codigo(servicio.ejecutar(comando("ana@gmail.com", "Secreta1", "45871236", "95175346", NACIMIENTO))));
        assertEquals(UsuarioError.PASSWORD_INVALIDO.name(),
                codigo(servicio.ejecutar(comando("ana@gmail.com", "", "45871236", "951753468", NACIMIENTO))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(null)));
        assertNoSeRegistroNada();
    }

    @Disabled("HALLAZGO H2: la longitud mínima de la contraseña solo se valida en FrmRegistro (>= 6). "
            + "El caso de uso acepta cualquier contraseña no vacía, por ejemplo \"1\".")
    @Test
    void rechazaContrasenasDemasiadoCortas() {
        var resultado = servicio.ejecutar(comando("ana@gmail.com", "1", "45871236", "951753468", NACIMIENTO));

        assertEquals(UsuarioError.PASSWORD_INVALIDO.name(), codigo(resultado));
        assertNoSeRegistroNada();
    }
}
