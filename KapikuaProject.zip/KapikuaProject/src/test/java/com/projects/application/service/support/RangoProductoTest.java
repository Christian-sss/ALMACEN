package com.projects.application.service.support;

import com.projects.domain.model.TipoProductoCrediticio;
import com.projects.domain.model.credito.ProductoCrediticio;
import com.projects.domain.result.CreditoError;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RangoProductoTest {

    // Microcrédito: S/ 100 a S/ 3 000, de 1 a 12 meses.
    private final ProductoCrediticio producto = new ProductoCrediticio(2L, "Microcredito",
            new BigDecimal("100.00"), new BigDecimal("3000.00"), TipoProductoCrediticio.MICROCREDITO, 1, 12, new BigDecimal("60.00"));

    private String validar(String monto, int plazo) {
        return codigo(RangoProducto.validar(producto, new BigDecimal(monto), plazo));
    }

    @Test
    void losLimitesDelRangoSonValidos() {
        assertTrue(RangoProducto.validar(producto, new BigDecimal("100.00"), 1).isSuccess());
        assertTrue(RangoProducto.validar(producto, new BigDecimal("3000.00"), 12).isSuccess());
    }

    @Test
    void rechazaMontosFueraDelRango() {
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("99.99", 6));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("3000.01", 6));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("0", 6));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("-500", 6));
    }

    @Test
    void rechazaPlazosFueraDelRango() {
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("500", 0));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("500", 13));
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("500", -3));
    }

    @Test
    void rechazaMontosConMasDeDosDecimales() {
        assertEquals(CreditoError.FUERA_DE_RANGO.name(), validar("500.005", 6));
    }
}
