package com.projects.application.service;

import com.projects.application.dto.response.SesionIniciadaResponse;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CerrarSesionServiceTest {

    private EnMemoria.Sesion sesion;
    private EnMemoria.Sesiones sesiones;
    private CerrarSesionService servicio;

    @BeforeEach
    void preparar() {
        sesion = new EnMemoria.Sesion();
        sesiones = new EnMemoria.Sesiones();
        servicio = new CerrarSesionService(sesion, sesiones);
    }

    @Test
    void alCerrarSesionSeLiberaLaCuentaParaOtroInicio() {
        sesiones.registrar(1L, "t1");
        sesion.iniciar(new SesionIniciadaResponse(1L, "ana@gmail.com", 1L, "CLIENTE", "t1"));

        assertTrue(servicio.cerrarSesion().isSuccess());

        assertTrue(sesion.obtenerActual().isEmpty());
        assertTrue(sesiones.activas.isEmpty());
        assertTrue(sesiones.registrar(1L, "t2"));
    }

    // Una instancia con token viejo no puede liberar la sesión de otra instancia.
    @Test
    void soloLiberaLaSesionCuyoTokenCoincide() {
        sesiones.registrar(1L, "t-nuevo");
        sesion.iniciar(new SesionIniciadaResponse(1L, "ana@gmail.com", 1L, "CLIENTE", "t-viejo"));

        servicio.cerrarSesion();

        assertEquals("t-nuevo", sesiones.activas.get(1L));
    }

    @Test
    void sinSesionAbiertaCerrarNoFalla() {
        assertTrue(servicio.cerrarSesion().isSuccess());
    }

    @Test
    void unaSesionSinTokenSoloSeCierraLocalmente() {
        sesiones.registrar(1L, "t1");
        sesion.iniciar(new SesionIniciadaResponse(1L, "ana@gmail.com", 1L, "CLIENTE"));

        servicio.cerrarSesion();

        assertTrue(sesion.obtenerActual().isEmpty());
        assertEquals("t1", sesiones.activas.get(1L));
    }
}
