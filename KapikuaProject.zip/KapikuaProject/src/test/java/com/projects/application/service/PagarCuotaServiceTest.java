package com.projects.application.service;

import com.projects.application.dto.command.PagarCuotaCommand;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.model.EstadoCuota;
import com.projects.domain.model.EstadoPrestamo;
import com.projects.domain.model.credito.Prestamo;
import com.projects.domain.result.BilleteraError;
import com.projects.domain.result.CreditoError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PagarCuotaServiceTest {

    private static final long ANA = 1;
    private static final long LUIS = 2;
    private static final long BILLETERA_ANA = 11;
    private static final long PRESTAMO = 7;

    private EnMemoria.Billeteras billeteras;
    private EnMemoria.Prestamos prestamos;
    private EnMemoria.Cuotas cuotas;
    private EnMemoria.Pagos pagos;
    private EnMemoria.TransaccionesGuardadas transacciones;
    private EnMemoria.Movimientos movimientos;
    private PagarCuotaService servicio;

    @BeforeEach
    void preparar() {
        // Préstamo de S/ 340 en 2 cuotas: 183.64 (155.20 + 28.44) y 189.82 (184.80 + 5.02).
        prepararCon("500.00", EstadoPrestamo.ACTIVO, new EnMemoria.Cuotas()
                .con(PRESTAMO, 1, "155.20", "28.44", "0.00", EstadoCuota.PENDIENTE)
                .con(PRESTAMO, 2, "184.80", "5.02", "0.00", EstadoCuota.PENDIENTE));
    }

    private void prepararCon(String saldo, EstadoPrestamo estado, EnMemoria.Cuotas cuotasDelPrestamo) {
        billeteras = new EnMemoria.Billeteras()
                .con(BILLETERA_ANA, ANA, saldo, EstadoBilletera.ACTIVA)
                .con(22, LUIS, "900.00", EstadoBilletera.ACTIVA);
        prestamos = new EnMemoria.Prestamos().con(new Prestamo(PRESTAMO, 70L, new BigDecimal("340.00"),
                new BigDecimal("40.00"), new BigDecimal("340.00"), estado, OffsetDateTime.now()), ANA);
        cuotas = cuotasDelPrestamo;
        pagos = new EnMemoria.Pagos();
        transacciones = new EnMemoria.TransaccionesGuardadas();
        movimientos = new EnMemoria.Movimientos();
        servicio = new PagarCuotaService(prestamos, prestamos, cuotas, pagos, billeteras, transacciones,
                movimientos, new EnMemoria.Tipos(), new EnMemoria.Transacciones());
    }

    private Prestamo prestamo() {
        return prestamos.porId.get(PRESTAMO);
    }

    @Test
    void pagaLaPrimeraCuotaPendienteCompleta() {
        var respuesta = servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO)).getValue().orElseThrow();

        assertEquals(1, respuesta.numeroCuota());
        assertMonto("183.64", respuesta.montoPagado());
        assertMonto("316.36", billeteras.saldoDe(BILLETERA_ANA));
        assertEquals(EstadoCuota.PAGADA, cuotas.numero(1).getEstado());
        assertEquals(EstadoCuota.PENDIENTE, cuotas.numero(2).getEstado());
    }

    // Solo el capital amortiza la deuda; el interés es ingreso de la entidad.
    @Test
    void soloElCapitalReduceElSaldoDelPrestamo() {
        servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));

        assertMonto("184.80", prestamo().getSaldoCapital());
        assertEquals(EstadoPrestamo.ACTIVO, prestamo().getEstado());
    }

    @Test
    void registraTransaccionMovimientoPagoYDetalle() {
        servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));

        var transaccion = transacciones.guardadas.get(0);
        assertEquals(EnMemoria.Tipos.PAGO_CREDITO, transaccion.getTipoId());
        assertMonto("183.64", transaccion.getMonto());
        assertEquals("Préstamo #7 · Cuota 1", transaccion.getReferencia());

        var movimiento = movimientos.guardados.get(0);
        assertEquals('-', movimiento.getSigno());
        assertMonto("316.36", movimiento.getSaldoPosterior());

        assertEquals(1, pagos.guardados.size());
        assertEquals(transaccion.getId(), pagos.guardados.get(0).getTransaccionId());
        var detalle = pagos.detalles.get(0);
        assertMonto("155.20", detalle.getCapitalAplicado());
        assertMonto("28.44", detalle.getInteresAplicado());
        assertMonto("0", detalle.getMoraAplicado());
    }

    @Test
    void alPagarLaUltimaCuotaElPrestamoQuedaPagadoYSinDeuda() {
        servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));
        var respuesta = servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO)).getValue().orElseThrow();

        assertEquals(2, respuesta.numeroCuota());
        assertTrue(respuesta.prestamoPagado());
        assertEquals(EstadoPrestamo.PAGADO, prestamo().getEstado());
        assertMonto("0", prestamo().getSaldoCapital());
        assertMonto("126.54", billeteras.saldoDe(BILLETERA_ANA));
    }

    @Test
    void unPrestamoPagadoNoAdmiteMasPagos() {
        servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));
        servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));

        var resultado = servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));

        assertEquals(CreditoError.PRESTAMO_NO_VIGENTE.name(), codigo(resultado));
        assertMonto("126.54", billeteras.saldoDe(BILLETERA_ANA));
        assertEquals(2, pagos.guardados.size());
    }

    @Test
    void sinSaldoSuficienteNoSePagaNiSeRegistraNada() {
        prepararCon("183.63", EstadoPrestamo.ACTIVO, new EnMemoria.Cuotas()
                .con(PRESTAMO, 1, "155.20", "28.44", "0.00", EstadoCuota.PENDIENTE));

        var resultado = servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO));

        assertEquals(BilleteraError.SALDO_INSUFICIENTE.name(), codigo(resultado));
        assertMonto("183.63", billeteras.saldoDe(BILLETERA_ANA));
        assertEquals(EstadoCuota.PENDIENTE, cuotas.numero(1).getEstado());
        assertMonto("340.00", prestamo().getSaldoCapital());
        assertTrue(transacciones.guardadas.isEmpty());
        assertTrue(pagos.guardados.isEmpty());
    }

    @Test
    void nadiePagaElPrestamoDeOtroCliente() {
        var resultado = servicio.ejecutar(new PagarCuotaCommand(LUIS, PRESTAMO));

        assertEquals(CreditoError.SIN_PERMISO.name(), codigo(resultado));
        assertMonto("900.00", billeteras.saldoDe(22));
        assertEquals(EstadoCuota.PENDIENTE, cuotas.numero(1).getEstado());
    }

    @Test
    void unPrestamoInexistenteNoSePaga() {
        assertEquals(CreditoError.PRESTAMO_NO_ENCONTRADO.name(), codigo(servicio.ejecutar(new PagarCuotaCommand(ANA, 999L))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new PagarCuotaCommand(ANA, null))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(null)));
    }

    @Test
    void unaCuotaVencidaSeCobraConSuMoraYElPrestamoSaleDeMora() {
        prepararCon("500.00", EstadoPrestamo.EN_MORA, new EnMemoria.Cuotas()
                .con(PRESTAMO, 1, "155.20", "28.44", "15.00", EstadoCuota.VENCIDA)
                .con(PRESTAMO, 2, "184.80", "5.02", "0.00", EstadoCuota.PENDIENTE));

        var respuesta = servicio.ejecutar(new PagarCuotaCommand(ANA, PRESTAMO)).getValue().orElseThrow();

        assertMonto("198.64", respuesta.montoPagado());
        assertMonto("15.00", pagos.detalles.get(0).getMoraAplicado());
        assertMonto("301.36", billeteras.saldoDe(BILLETERA_ANA));
        assertEquals(EstadoPrestamo.ACTIVO, prestamo().getEstado());
        assertFalse(respuesta.prestamoPagado());
    }
}
