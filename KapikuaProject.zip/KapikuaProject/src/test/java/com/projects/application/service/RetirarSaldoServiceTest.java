package com.projects.application.service;

import com.projects.application.dto.command.RetirarSaldoCommand;
import com.projects.domain.model.EstadoBilletera;
import com.projects.domain.result.BilleteraError;
import com.projects.testsupport.EnMemoria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.projects.testsupport.EnMemoria.assertMonto;
import static com.projects.testsupport.EnMemoria.codigo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RetirarSaldoServiceTest {

    private static final long ANA = 1;
    private static final long BILLETERA_ANA = 11;
    private static final String CUENTA = "19112345678901";

    private EnMemoria.Billeteras billeteras;
    private EnMemoria.TransaccionesGuardadas transacciones;
    private EnMemoria.Movimientos movimientos;
    private RetirarSaldoService servicio;

    @BeforeEach
    void preparar() {
        prepararCon(EstadoBilletera.ACTIVA);
    }

    private void prepararCon(EstadoBilletera estado) {
        billeteras = new EnMemoria.Billeteras().con(BILLETERA_ANA, ANA, "100.00", estado);
        transacciones = new EnMemoria.TransaccionesGuardadas();
        movimientos = new EnMemoria.Movimientos();
        servicio = new RetirarSaldoService(billeteras, transacciones, movimientos,
                new EnMemoria.Tipos(), new EnMemoria.Transacciones());
    }

    private String retirar(String cuenta, String monto) {
        return codigo(servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", cuenta, new BigDecimal(monto))));
    }

    private void assertNadaCambio() {
        assertMonto("100.00", billeteras.saldoDe(BILLETERA_ANA));
        assertTrue(transacciones.guardadas.isEmpty());
        assertTrue(movimientos.guardados.isEmpty());
    }

    @Test
    void debitaYRegistraLaTransaccionConSuMovimiento() {
        var respuesta = servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", CUENTA, new BigDecimal("40.00")))
                .getValue().orElseThrow();

        assertMonto("60.00", billeteras.saldoDe(BILLETERA_ANA));
        assertMonto("60.00", respuesta.saldoResultante());

        assertEquals(1, transacciones.guardadas.size());
        assertEquals(EnMemoria.Tipos.RETIRO, transacciones.guardadas.get(0).getTipoId());

        assertEquals(1, movimientos.guardados.size());
        assertEquals('-', movimientos.guardados.get(0).getSigno());
        assertMonto("60.00", movimientos.guardados.get(0).getSaldoPosterior());
    }

    // Dato sensible: en la BD y en el comprobante solo quedan los últimos 4 dígitos de la cuenta.
    @Test
    void laReferenciaEnmascaraElNumeroDeCuenta() {
        var respuesta = servicio.ejecutar(new RetirarSaldoCommand(ANA, " BCP ", " " + CUENTA + " ", new BigDecimal("40.00")))
                .getValue().orElseThrow();

        assertEquals("BCP ****8901", respuesta.referencia());
        assertEquals("BCP ****8901", transacciones.guardadas.get(0).getReferencia());
    }

    @Test
    void elMontoMinimoEsDiezSoles() {
        assertEquals(BilleteraError.MONTO_MINIMO_NO_ALCANZADO.name(), retirar(CUENTA, "9.99"));
        assertEquals(BilleteraError.MONTO_MINIMO_NO_ALCANZADO.name(), retirar(CUENTA, "0"));
        assertEquals(BilleteraError.MONTO_MINIMO_NO_ALCANZADO.name(), retirar(CUENTA, "-40"));
        assertNadaCambio();

        assertTrue(servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", CUENTA, new BigDecimal("10.00"))).isSuccess());
    }

    @Test
    void laCuentaDebeTenerEntreDiezYVeinteDigitos() {
        for (var cuenta : new String[]{"", "123456789", "123456789012345678901", "1911234567890A", "1911-2345-6789"}) {
            assertEquals(BilleteraError.CUENTA_INVALIDA.name(), retirar(cuenta, "40"), "cuenta: " + cuenta);
        }
        assertNadaCambio();
    }

    @Test
    void rechazaSiElSaldoNoAlcanza() {
        assertEquals(BilleteraError.SALDO_INSUFICIENTE.name(), retirar(CUENTA, "100.01"));
        assertNadaCambio();
    }

    @Test
    void unaBilleteraBloqueadaNoRetira() {
        prepararCon(EstadoBilletera.BLOQUEADA);

        assertEquals(BilleteraError.BILLETERA_INACTIVA.name(), retirar(CUENTA, "40"));
        assertNadaCambio();
    }

    @Test
    void exigeTodosLosDatosDelComando() {
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(null)));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new RetirarSaldoCommand(null, "BCP", CUENTA, BigDecimal.TEN))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new RetirarSaldoCommand(ANA, " ", CUENTA, BigDecimal.TEN))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", null, BigDecimal.TEN))));
        assertEquals("COMANDO_INVALIDO", codigo(servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", CUENTA, null))));
    }

    @Test
    void unClienteSinBilleteraNoRetira() {
        var resultado = servicio.ejecutar(new RetirarSaldoCommand(999L, "BCP", CUENTA, new BigDecimal("40")));

        assertEquals(BilleteraError.BILLETERA_NO_ENCONTRADA.name(), codigo(resultado));
    }

    @Disabled("HALLAZGO H1: el servicio acepta montos con más de 2 decimales. Retirar 10.004 deja el saldo en "
            + "89.996, que NUMERIC(12,2) guarda como 90.00: el cliente retira 10.004 y solo se le descuenta 10.00.")
    @Test
    void rechazaMontosConMasDeDosDecimales() {
        var resultado = servicio.ejecutar(new RetirarSaldoCommand(ANA, "BCP", CUENTA, new BigDecimal("10.004")));

        assertTrue(resultado.isFailure());
        assertNadaCambio();
    }
}
