package com.projects.infrastructure.config;

import com.projects.application.port.in.CerrarSesionUseCase;
import com.projects.application.port.out.SesionContexto;
import com.projects.application.port.out.SesionRepository;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Mantiene viva la sesión registrada en la base de datos mientras la app está abierta
 * y la libera al cerrar la JVM. Sin esto, una caída dejaría la cuenta bloqueada.
 */
final class MantenimientoSesion {

    private static final int SEGUNDOS_ENTRE_LATIDOS = 30;

    private boolean iniciado;

    synchronized void iniciar(SesionContexto contexto, SesionRepository repositorio, CerrarSesionUseCase cerrar) {
        if (iniciado) {
            return;
        }
        iniciado = true;

        var latidos = Executors.newSingleThreadScheduledExecutor(r -> {
            var hilo = new Thread(r, "latido-sesion");
            hilo.setDaemon(true);
            return hilo;
        });
        latidos.scheduleAtFixedRate(() -> {
            try {
                contexto.obtenerActual()
                        .filter(s -> s.token() != null)
                        .ifPresent(s -> repositorio.latido(s.usuarioId(), s.token()));
            } catch (RuntimeException ignorada) {
                // Un fallo de red puntual no debe cancelar los latidos siguientes.
            }
        }, SEGUNDOS_ENTRE_LATIDOS, SEGUNDOS_ENTRE_LATIDOS, TimeUnit.SECONDS);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                cerrar.cerrarSesion();
            } catch (RuntimeException ignorada) {
                // Si no hay red, la fila expira sola.
            }
        }, "cierre-sesion"));
    }
}
